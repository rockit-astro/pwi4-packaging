// Functions dealing with formatting and parsing sexagesimal strings
// Generally used for converting between decimal degrees or hours
// to [degrees,hours]/minutes/seconds.

/** Convert components of a sexagesimal number into a decimal value
 *  @param {number} sign -1 for a negative value, 1 for a positive
 *  @param {number} degrees The degrees portion of the value
 *  @param {number} minutes The minutes portion of the value
 *  @param {number} seconds The seconds portion of the value
 *  @return {number} The decimal representation of the sexagesimal components
 */
function dmsToFloat(sign, degrees, minutes, seconds)
{
    return sign*(degrees + minutes/60.0 + seconds/3600.0);
}

/** Splits up a decimal value into sexagesimal components
 *  @param {string} val The value to split
 *  @return {array} An array [sign, degs, mins, secs]. Sign is -1 for negative values,
 *          or +1 for positive values
 */
function floatToDms(val)
{
    var sign = 1;
    if (val < 0) {
        sign = -1;
        val = -val;
    }

    var d = Math.floor(val);
    val = 60*(val-d);
    var m = Math.floor(val);
    var s = 60*(val-m);

    return [sign, d, m, s];
}

/** Parse a sexagesimal string of the form "-DD:MM:SS.s"
 *  For example, "10:30:00" is converted to "10.5"
 *  Fields may be separated by space, ":", or "_"
 *  Valid formats also include "DD.ddd" and "DD:MM.mmm"
 *
 *  @param {string} str The string to parse
 *  @return {number} The floating point value of the sexagesimal string
 */
function parseDms(str)
{
    var fields = str.split(/[ :_]/);
    var sign = 1;
    var result = 0;

    if (fields[0] < 0) {
        sign = -1;
        fields[0] = -fields[0];
    }

    var denom = 1.0;

    for (var i in fields) {
        var field = fields[i];
        result += field/denom;
        denom *= 60;
    }

    return sign*result;
}

/** Convert a number to a sexagesimal string of the form "dd:mm:ss"
 *  @param {number} val The floating point value to convert
 *  @param {string} sep The separator to insert between fields; ":" by default
 *  @param {number} decimals Number of digits after the seconds decimal point
 *  @return {string} A string formatted in sexagesimal notation
 */
function formatDms(val, sep, decimals)
{
    if (sep === undefined) {
        sep = ":";
    }
    
    if (decimals === undefined) {
        decimals = 1;
    }

    // Utility inner function to zero-pad single digit strings, so we don't 
    // have to include entire printf library
    var pad = function (n) {
        if (n < 10) return "0" + n;
        return "" + n;
    };

    var fields = floatToDms(val);
    
    var result = "";
    if (fields[0] < 0) {
        result = "-";
    }

    var secondsLength = 2;
    if (decimals > 0) {
        secondsLength = 3+decimals;
    }
    
    result += pad(fields[1]) + sep
            + pad(fields[2]) + sep
            + pad(fields[3]).substr(0, secondsLength);

    return result;
}
